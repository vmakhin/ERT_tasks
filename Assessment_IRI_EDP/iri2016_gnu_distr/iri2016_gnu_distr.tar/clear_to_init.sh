rm *.txt
rm *.for
rm *.dat
rm *.tar
rm *.asc
